#include "CreditCard.h"

void main()
{

	try
	{
		CreditCard card("mihnea","1234");
		//std::cin >> card;

		card.addTransactions("trip to London",120,100);
		card.addTransactions("lake walking", Money(12, 56));

		std::cout << card;
	}
	catch (std::exception)
	{
		std::cout << "Error!";
	}
	
	
}
