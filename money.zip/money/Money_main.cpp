# include"Money.h"

void main()
{

	try {

		Money money(2, 99);
		//std::cin >> money;
		std::cout << money+money+money<<"\n";
	}
	catch(std::exception)
	{
		std::cout << " Error! ";
	}
}